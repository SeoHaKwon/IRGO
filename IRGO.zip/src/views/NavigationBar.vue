<template>
  <div class="NavigationBar">
    <header>
      <div class="header-logo">
        <img width="155px" src="./assets/img/img_header_logo.png" />
      </div>
    </header>
  </div>
</template>

<style lang="scss">
.NavigationBar {
  header {
    width: 1150px;
    margin: 0 auto;
  }
}
</style>
